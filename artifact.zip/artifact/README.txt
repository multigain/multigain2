= Requirements =

Linux operating system with Docker (Tested with: Docker version 20.10.24).

= Gurobi =

To use the LP solver Gurobi (strongly encouraged!) in the docker, you may acquire a (free for acedemic use) license to the WLS servers in the Gurobi Web License Manager at
https://license.gurobi.com
For further information we refer the user to the documentation:
https://license.gurobi.com/manager/doc/overview
After acquiring the license, download the license file and place it as "gurobi.lic" into the "build" directory.

= Running the Experiments =

*Open a terminal in the directory of this README.

* Execute the command (1.) to build the docker image (requires ~1.5GB memory, ~5 minutes). Alternatively if you want to install Gurobi (strongly encouraged) with MULTIGAIN 2.0 follow the instructions in the "Gurobi" section above and use command (2.) for building the docker image.

1. docker build -t multigain2 build/
2. docker build -t multigain2 build/ --build-arg GUROBI=true

* Run the docker image using the following command:

docker run -v "$(pwd)/results:/home/multigain2/results:rw" \
    -v "$(pwd)/examples:/home/multigain2/examples/host:ro" \
    -w "/home/multigain2" \
    -it multigain2 bash
    
* You have now entered the multigain2 directory inside the container:
    *./examples: Contains the examples from the paper

* Each "examples" subdirectory contains a bash script to run all examples, which may be executed from any working directory. The results are logged into the ./results directory.

= Experimental results =
All experiments from the corresponding tool paper were performed on a computer with 16 GB of RAM and an Intel i7-8550U @ 1.80GHz CPU, running Ubuntu 22.04.3 LTS, using Gurobi as the LP solver. 
Note that the docker container does not support visualization of the Pareto frontiers.


= Table 1 =
Given the potentially lengthy duration of these experiments, the process has been split into two separate scripts for efficiency. The `experiments-table-1-4-32.sh`script (~ 4 mins. runtime) runs the experiments for grid sizes ranging from 4x4 to 32x32, and the `experiments-table-1-64.sh` (~ 30 mins. runtime) runs the 64x64 grid size experiments. The former script creates a .txt file with the following structure. 

LTL,LRA,4x4,16x16,32x32
G(¬b)∧(GF b),x,
(GFa)∨(FGb),x,
(Fa)Ub,x,
(Fa)∧(Fb)∧(Fc),x,
G(¬b)∧(GF b),v,
(GFa)∨(FGb),v,
(Fa)Ub,v,
(Fa)∧(Fb)∧(Fc),v,

 The `experiments-table-1-4-32.sh` and `experiments-table-1-64.sh` scripts create the `table1-4-32.txt` and `table1-64.txt` files within the `/results/grid` directory.
 
Please note that due to the inherent randomness in the model generation process, the average running times may not precisely match those reported in the paper. 


= Figure 6 =
We do not support visualization of the running times. However, the average running times for each formula that were used to plot Figure 6 are shown below in table format.

Formula Number of ss constraints Average time (s)
1  	10                 0.9063
2               10	   9.27
3               10	   5.897 

1 	50                 1.113
2	50	   8.605
3               50                 10.84

1  	200                1.721
2	200	   14.32
3               200                23.798

1  	500                2.34
2	500	   14.745
3               500                26.63 
	

To run this experiment, start the process by running the ./experiments-figure-6.sh (~ 20 mins. runtime) script. This script will subsequently call four different scripts (ss-exp-10.sh, ss-exp-50.sh, ss-exp-200.sh, ss-exp-500.sh).
 Each of these scripts is responsible for verifying the three different formulae for a particular number of steady-state constraints and will produce a corresponding .csv file. As a result, four .csv files will be created (griddet64_ss10_with_new_results.csv, griddet64_ss50_with_new_results.csv, griddet64_ss200_with_new_results.csv, griddet64_ss500_with_new_results.csv). Each file, griddet64_ssN_with_new_results.csv, contains the running times for the three specified formulae under N steady-state constraints. Finally, the average running times for each formula will be displayed on the screen from the respective .csv files, which allows for a straightforward comparison with the table above.

= Table 2=
Given the potentially lengthy duration of these experiments, the process has been split into two separate scripts for efficiency. The `experiments-table-2-4-32.sh`(~30 mins) script runs the experiments for grid sizes ranging from 4x4 to 32x32, and the `experiments-table-2-64.sh` (~50 mins) runs the 64x64 grid size experiments. The former script creates a .txt file with the following structure.

LTL,LRA,4x4_gurobi,4x4_no_gurobi,16x16_gurobi,16x16_no_gurobi,32x32_gurobi,32x32_no_gurobi
(GFa)∨(FGb),x,
(Fa)Ub,x,
(Fa)∧(Fb)∧(Fc),x,
(GFa)∨(FGb),v,
(Fa)Ub,v,
(Fa)∧(Fb)∧(Fc),v 

 The `experiments-table-2-4-32.sh` and `experiments-table-2-64.sh` scripts create the `table2-4-32.txt` and `table2-64.txt` files within the `/results/grid` directory.

= Custom Models =    
    
To solve custom models and queries, place your model and property files in the "examples" directory before running the docker image. The directory will be mounted inside the docker environment as ./examples/host. You can run your custom examples with the following general command from the root of the multigain2 directory (inside the docker environment):

bin/multigain2 ./examples/host/model_file_name ./examples/host/property_file_name 

To log the output instead of printing it to the console the user may add "> ./results/host/log_file_name.log" to the end of the command. Further options such as GUROBI or policy export are also available.
    
=== Installation without Docker =

To manually build MULTIGAIN 2.0 without docker, please extract the ZIP-file "multigain2.zip" in the "build" directory.

----
unzip multigain2.zip
cd multigain2
cd prism-4.7-src/prism
make clean_all
make
----

[NOTE]
====
If the environment variable `GUROBI_HOME` is not set expect the following message during compilation:
----
GUROBI HOME is not set. Not compiling Gurobi support
make[1]: Leaving directory ’.../multigain2/prism/prism/ext/gurobi´
----
This is not an error message, but a warning.

====
You can test if the installation finished correctly by running this example:

----
bin/prism examples/example.prism examples/example.props
----

==== Install with Gurobi
If you want to use Gurobi you additionally have to copy the Gurobi library files into the library folder:

----
cp -r $GUROBI_HOME/lib/* lib/
----
Test your Gurobi installation by running the example with gurobi
----
bin/prism examples/example.prism examples/example.props --gurobi
----
TIP: If you want to use Gurobi in an IntelliJ run configuration you have to mark `prism/ext/solver/gurobi` as source

=== Plotting Pareto Curves

For plotting Pareto curves generated by MULTIGAIN 2.0 we recommend installing Anaconda. Then create a new conda environment. For details and trouble shooting see: https://conda.io/projects/conda/en/latest/user-guide/tasks/manage-environments.html#creating-an-environment-with-commands


----
conda create -n multigain2 python=3.10
Proceed ([y]/n)? y
----
Activate the environment and install the required packages:

----
conda activate multigain2
pip install argparse matplotlib
----
Assuming you are still located in the prism directory, you can test the installation by plotting one of our pregenerated files:

----
python ./etc/scripts/pareto-plot.py examples/results/pareto2d.pareto
----


=== Property Specification

==== Query Wrappers
As entry point for *MultiGain 2.0* functionality every query in the property file has to be wrapped with the `multi(...)`, `mlessmulti(...)`, `unichain(...)` or `detmulti(...)` keyword.

The `*multi*` keyword describes the standard functionality of *MultiGain 2.0*. It allows for an LTL-Specification, Steady-State-Specifications and arbitrary many (quantitative) reward specification.

The `*mlessmulti*` keyword may be used in case the `multi` keyword results in an unbound memory policy. The policy allows for an additional integer literal at the front of the property list. This integer fixes the maximum number of steps the policy takes before visiting an accepting state again in the long run. The resulting policy therefore requires only finite memory.
The tool will then ouput the minimal relaxation factor `delta`] we have to relax the steady-state and boolean reward constraints with. Since the objective function is preoccupied with `delta` it is not possible to specify quantitative reward properties in an `mlessmulti` query.

The `*unichain*` keyword allows the same properties as a standard `multi` query with a maximum of one quantitative reward specifications. *MULTIGAIN 2.0* will then compute if there exists a solution to the query whose corresponding policy constitutes a unichain on the MDP.
This is achieved by iteratively searching through the maximum end components of the MDP. If a quantitative reward is specified, *MULTIGAIN 2.0* will return the unichain solution maximizing (or minimizing) the respective reward structure.

The `*detmulti*` keyword allows for an LTL-Specification and arbitrary many Steady-State-Specifications. *MULTIGAIN 2.0* will compute a deterministic unichain policy following the approach by A. Velasquez et al.:[Velasquez, A., Alkhouri, I., Beckus, A., Trivedi, A., Atia, G.: Controller synthesis for omega-
regular and steady-state specifications. In: Proceedings of the 21st International Conference
on Autonomous Agents and Multiagent Systems. p. 1310–1318. AAMAS ’22, International
Foundation for Autonomous Agents and Multiagent Systems, Richland, SC (2022)]

==== Accepting Frequency Bound
This is exclusively allowed at the start of the property list in an `mlessmulti` query. The bound is denoted as a single integer literal, as in the examples below.
It specifies the maximum number of steps the policy takes before visiting an accepting state again in the long run.

==== Reward-Specification
Reward constraints can be specified using the `R` operator. These may be of qualitative (boolean) (`>=`,`\<=`) or quantitative (`max=?`, `min=?`) nature. Quantitative reward specifications aim to optimise the corresponding rewards value. If more than one quantitative specifications are included, *MULTIGAIN 2.0* will approximate the Pareto curve.

==== LTL-Specification
LTL formulas may be specified using the `P` operator. The notation does not differ from the standard Prism
notation for temporal logics. Only one LTL specification may be specified per query.

==== Steady-State-Specification
Steady-State constraints can be defined with the `S` operator. The notation does not differ from the
standard Prism notation for steady-state-constraints. You can specify multiple steady-state-constraints per query.

TIP: To specify a Steady-State-Constraint with an equality operator, please default
to using two `S` operators, with `\<=` and `>=`.

==== Examples

----
multi(R{"reward1"}max=? [S], R{"reward2"}>=0.25 [S], S>=0.25 ["ssLabel"], P>=1 [F state!=2])
----
----
multi(R{"reward1"}max=? [ S ], R{"reward2"}max=? [ S ], P>=1 [ G state!=1 ], S>=0.5 [ "someLabel" ])
----
----
mlessmulti(100, P>=1 [ G F "acc" ], S>=1 [ "ss" ])
----
----
unichain(R{"unbalanced"}max=? [S], P>=1 [(F "a") | (F "b")])
----
----
detmulti(P>=0.75 [(! "danger") U "tool"], S>=0.75 ["home"], S<=1 ["home"])
----

NOTE: More examples can be found in the `examples` directory.
